/**
 * The mic "orb" — button and status indicator in one.
 * The halo ring scales with the live microphone level (Web Audio API),
 * so the UI visibly reacts to the user's voice while listening.
 */
export default function MicOrb({ state, level, onClick }) {
  return (
    <button
      className={`orb ${state}`}
      onClick={onClick}
      aria-label="Toggle microphone"
    >
      <span
        className="halo"
        style={{ transform: `scale(${1 + level * 1.8})` }}
      />
      <span className="ring" />
      <span className="core">
        <svg viewBox="0 0 24 24" width="34" height="34" fill="currentColor">
          <path d="M12 14a3 3 0 0 0 3-3V5a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3zm5-3a5 5 0 0 1-10 0H5a7 7 0 0 0 6 6.92V21h2v-3.08A7 7 0 0 0 19 11h-2z" />
        </svg>
      </span>
    </button>
  );
}
