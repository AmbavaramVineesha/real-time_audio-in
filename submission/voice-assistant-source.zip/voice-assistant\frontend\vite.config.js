import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    // During development (npm run dev), forward API calls to FastAPI.
    proxy: {
      "/chat": "http://localhost:8000",
    },
  },
});
