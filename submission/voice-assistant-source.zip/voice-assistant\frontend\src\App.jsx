import useVoiceAssistant from "./hooks/useVoiceAssistant";
import Transcript from "./components/Transcript";
import MicOrb from "./components/MicOrb";

export default function App() {
  const va = useVoiceAssistant();

  return (
    <main className="app">
      <header className="topbar">
        <h1>
          <span className="logo">◉</span> AURA
          <span className="sub">real-time voice AI</span>
        </h1>
        <div className="badges">
          <span className={"badge " + (va.online ? "ok" : "warn")}>
            {va.online ? "● online" : "● fallback mode"}
          </span>
          {va.lastLatency && (
            <span className="badge accent">⚡ {va.lastLatency}s</span>
          )}
        </div>
      </header>

      <Transcript turns={va.turns} />

      <div className="interim">{va.interim ? `“${va.interim}…”` : ""}</div>

      <footer className="controls">
        <div className="status">{va.status}</div>
        <MicOrb
          state={va.micState}
          level={va.micLevel}
          onClick={va.toggle}
        />
        <div className="hint">
          Conversation mode: the mic reopens automatically after each answer.
          Tap the orb again to stop or interrupt.
        </div>
      </footer>
    </main>
  );
}
