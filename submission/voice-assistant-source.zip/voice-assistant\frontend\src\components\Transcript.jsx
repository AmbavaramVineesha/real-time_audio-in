import { useEffect, useRef } from "react";

/** Chat history. Auto-scrolls as tokens stream into the newest bubble. */
export default function Transcript({ turns }) {
  const ref = useRef(null);

  useEffect(() => {
    const el = ref.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [turns]);

  return (
    <section ref={ref} className="transcript">
      {turns.map((t) => (
        <div
          key={t.id}
          className={`msg ${t.role}${t.filler ? " filler" : ""}`}
        >
          <div className="bubble">
            {t.text}
            {t.latency && (
              <span className="turn-latency">
                ⚡ voice-to-voice: {t.latency}s
              </span>
            )}
          </div>
        </div>
      ))}
    </section>
  );
}
